# Better Synergy Menu
 Update to https://mod.io/g/melvoridle/m/better-summoning-menu
